﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Navigation;

namespace WpfApp1.Model
{
    public static class AppData
    {
        public static useerEntities2 db = new useerEntities2();
    }
}
